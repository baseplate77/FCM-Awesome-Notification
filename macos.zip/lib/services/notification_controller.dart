import 'dart:async';

import 'package:awesome_notifications/awesome_notifications.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../main.dart';
import '../temp_screen.dart';

navigateHelper(ReceivedAction receivedAction) {
  // this will check if there is playload and if the playload have screen name and it will navigate to specific screen
  if (receivedAction.payload != null &&
      receivedAction.payload!['screen_name'] == "TEMP_SCREEN") {
    MyApp.navigatorKey.currentState!
        .push(MaterialPageRoute(builder: (_) => const TempScreen()));
  }
}

class NotificationController extends ChangeNotifier {
  // SINGLETON PATTERN
  static final NotificationController _instance =
      NotificationController._internal();

  factory NotificationController() {
    return _instance;
  }

  NotificationController._internal();

// INITIALIZATION METHOD

  static Future<void> initializeLocalNotifications(
      {required bool debug}) async {
    await AwesomeNotifications().initialize(
      null,
      [
        NotificationChannel(
          channelKey: 'basic_channel',
          channelName: 'Basic notifications',
          channelDescription: 'Notification channel for basic tests',
          importance: NotificationImportance.Max,
          enableVibration: true,
          defaultColor: Colors.redAccent,
          channelShowBadge: true,
          enableLights: true,
        ),
      ],
      debug: debug,
    );
  }

// firebase listiner
  static firebaseMessageingListener() {
    FirebaseMessaging.onMessage.listen((remoteMessage) {
      print("onMessage Recevied : ${remoteMessage.toString()}");
      createNotificationFromJson(remoteMessage);
    });

// Ignore this method as Awesome notication listener will sever us best
    FirebaseMessaging.onMessageOpenedApp.listen((remoteMessage) {
      print("onMessageOpendedApp recevied : ${remoteMessage}");
    });
  }

  static createNotificationFromJson(RemoteMessage remoteMessage) async {
    print("data : ${remoteMessage.data}");
    await AwesomeNotifications()
        .createNotificationFromJsonData(remoteMessage.data);
  }

  createLocalNotification(RemoteMessage remoteMessage) async {
    print("data : ${remoteMessage.data}");
    await AwesomeNotifications().createNotification(
      content: NotificationContent(
        id: 2,
        channelKey: "basic_channel",
        title: "test Notifcaiton",
        body: "this notification is trigger form onMessage listner",
      ),
    );
  }

  static getFCMToken() async {
    final fcmToken = await FirebaseMessaging.instance.getToken();
    print("FCM token : $fcmToken");
  }

  static requrestNotificationPermission() async {
    await AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
      if (!isAllowed) {
        AwesomeNotifications().requestPermissionToSendNotifications();
      }
    });
  }

  static getInitialMessage() async {
    final remoteMessage = await FirebaseMessaging.instance.getInitialMessage();
    print("remote message receviced : ${remoteMessage.toString()}");
  }

  /// This method is call when a any given cause the app launch
  /// Note the app was terminated
  static Future<void> getInitialNotificationAction() async {
    ReceivedAction? receivedAction = await AwesomeNotifications()
        .getInitialNotificationAction(removeFromActionEvents: true);

    if (receivedAction == null) return;

    navigateHelper(receivedAction);
  }
}
