package com.example.notification_course

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
